

var botui = new BotUI('hello-world');
var flagMinimize = false;
var chatKeyWord = null;
//botui.message.removeall();
botui.message
    .add({
      content : 'Hello!! I am your DWBI Virtual Assistant.'
    });
$(document).ready(function() {
  $('#question').keydown(function(e) {
    if (e.keyCode == 13) {
      var question = $('#question').val();
      var jsondata = {
        'question': question,
        'keyWord' : chatKeyWord
      }
      console.log(jsondata);
      document.getElementById('question').value = "";
      botui.message.add({
        human : true,
        content : question
      });
      $.ajax({
        url : "http://10.140.19.34:8080/pythonexecutor",
        type : "POST",
        data : jsondata,
        contentType : "application/text; charset=utf-8",
        dataType : "text",
        crossOrigin : null,
        success : function(response) {
          botui.message.add({
            content : response
          });
        },
        failure : function(errMsg) {
          alert("Error");
        }
      });
    }
  }); //Key down ends here
});
function openForm(data) {

  if(!flagMinimize){
    chatKeyWord = data;
    if (data == "RNA") {
        botui.message
        .add({
          content : 'Looks like you are interested to learn about RNA, you can pose your questions starting with EXPLORE (E.g. EXPLORE RNA)'
        });
    } else if (data == "B360") {
    	botui.message
        .add({
          content : 'Looks like you are interested to learn about B360, you can pose your questions starting with EXPLORE (E.g. EXPLORE B360)'
        });
    } else if (data == "Dragons") {
    	botui.message
        .add({
          content : 'Looks like you are interested to learn about Dragons, you can pose your questions starting with EXPLORE (E.g. EXPLORE Dragons)'
        });
    } else if (data == "Data Warriors") {
    	botui.message
        .add({
          content : 'Looks like you are interested to learn about Data Warriors, you can pose your questions starting with EXPLORE (E.g. EXPLORE Data Warriors)'
        });
    } else {
    	botui.message
        .add({
          content : 'Looks like you are interested to learn about SDSA, you can pose your questions starting with EXPLORE (E.g. EXPLORE SDSA)'
        });
    }
  }
  document.getElementById("myForm").style.display = "block";
}
function minimizeForm() {
  flagMinimize = true;
  document.getElementById("myForm").style.display = "none";
}
function closeForm() {
  chatKeyWord = null;
  flagMinimize = false;
  botui.message.removeAll();
  botui.message
  botui.message.add({
      content : 'Hello!! I am your DWBI Virtual Assistant.'
    });
  document.getElementById("myForm").style.display = "none";

}
