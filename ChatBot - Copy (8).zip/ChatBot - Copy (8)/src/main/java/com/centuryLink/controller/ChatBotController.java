package com.centuryLink.controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path= {"/pythonexecutor" })
public class ChatBotController {
	

	@CrossOrigin(origins = "*")
	@PostMapping	
	public String getAnswer(@RequestBody String ajaxInput) {
		String chatInput = ajaxInput.replaceAll("%0", "");
		String[] input = chatInput.split("&");
		String question1 = input[0];
		String question = question1.replace('+', ' ').substring(9);
		String subject = input[1].replace('+', ' ').substring(8);
		StringBuilder builder = new StringBuilder();
		try {
			String python_val[] = new String[] { "C:\\Anaconda3\\python.exe",
					"C:\\Users\\AC38815\\Desktop\\ChatBot_Working_Files\\Python-Spyder Files\\untitled0.py",
					question.toUpperCase(), subject.toUpperCase()};
			ProcessBuilder pb = new ProcessBuilder(Arrays.asList(python_val));
			Process p = null;			

			if (pb != null) {
				try {
					p = pb.start();
				} catch (IOException e) {
					e.printStackTrace();
				}

				if (p != null) {
					try {
						int exitCode = p.waitFor();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
			
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(p.getInputStream()));
		    String line = bufferedReader.readLine();
		    while (line != null) {
		      builder.append(line).append(System.lineSeparator());
		      line = bufferedReader.readLine();
		    }
		    bufferedReader.close();	

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e);
		}
		
		System.out.println("question-->"+question.toUpperCase());
		System.out.println("answer-->"+builder.toString());
		return builder.toString();
		
	}	
}