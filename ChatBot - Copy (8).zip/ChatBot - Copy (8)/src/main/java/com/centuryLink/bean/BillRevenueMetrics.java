package com.centuryLink.bean;




public class BillRevenueMetrics {

	private String id;

	private String billingAddressLine1;

	private String billingAddressLine2;

	private String billingCityName;

	private String billingStateCode;

	private String billingPostalCode;

	private String billingCountryName;
	
	private String sourceSystemName;
	
	private String customerNumber;

	private String customerName;

	private String employeeUserName;

	private String glCustomerSegmentCode;

	private String salesRepId;

	private String salesRepName;
	
	private String prevYearToDateMrc;

	private String threeMonthAvgMrc;

	private String currentMrc;

	private String yearToDateMrc;

	private String yearToDateNrc;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getBillingAddressLine1() {
		return billingAddressLine1;
	}

	public void setBillingAddressLine1(String billingAddressLine1) {
		this.billingAddressLine1 = billingAddressLine1;
	}

	public String getBillingAddressLine2() {
		return billingAddressLine2;
	}

	public void setBillingAddressLine2(String billingAddressLine2) {
		this.billingAddressLine2 = billingAddressLine2;
	}

	public String getBillingCityName() {
		return billingCityName;
	}

	public void setBillingCityName(String billingCityName) {
		this.billingCityName = billingCityName;
	}

	public String getBillingStateCode() {
		return billingStateCode;
	}

	public void setBillingStateCode(String billingStateCode) {
		this.billingStateCode = billingStateCode;
	}

	public String getBillingPostalCode() {
		return billingPostalCode;
	}

	public void setBillingPostalCode(String billingPostalCode) {
		this.billingPostalCode = billingPostalCode;
	}

	public String getBillingCountryName() {
		return billingCountryName;
	}

	public void setBillingCountryName(String billingCountryName) {
		this.billingCountryName = billingCountryName;
	}

	public String getSourceSystemName() {
		return sourceSystemName;
	}

	public void setSourceSystemName(String sourceSystemName) {
		this.sourceSystemName = sourceSystemName;
	}

	public String getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmployeeUserName() {
		return employeeUserName;
	}

	public void setEmployeeUserName(String employeeUserName) {
		this.employeeUserName = employeeUserName;
	}

	public String getGlCustomerSegmentCode() {
		return glCustomerSegmentCode;
	}

	public void setGlCustomerSegmentCode(String glCustomerSegmentCode) {
		this.glCustomerSegmentCode = glCustomerSegmentCode;
	}

	public String getSalesRepId() {
		return salesRepId;
	}

	public void setSalesRepId(String salesRepId) {
		this.salesRepId = salesRepId;
	}

	public String getSalesRepName() {
		return salesRepName;
	}

	public void setSalesRepName(String salesRepName) {
		this.salesRepName = salesRepName;
	}

	public String getPrevYearToDateMrc() {
		return prevYearToDateMrc;
	}

	public void setPrevYearToDateMrc(String prevYearToDateMrc) {
		this.prevYearToDateMrc = prevYearToDateMrc;
	}

	public String getThreeMonthAvgMrc() {
		return threeMonthAvgMrc;
	}

	public void setThreeMonthAvgMrc(String threeMonthAvgMrc) {
		this.threeMonthAvgMrc = threeMonthAvgMrc;
	}

	public String getCurrentMrc() {
		return currentMrc;
	}

	public void setCurrentMrc(String currentMrc) {
		this.currentMrc = currentMrc;
	}

	public String getYearToDateMrc() {
		return yearToDateMrc;
	}

	public void setYearToDateMrc(String yearToDateMrc) {
		this.yearToDateMrc = yearToDateMrc;
	}

	public String getYearToDateNrc() {
		return yearToDateNrc;
	}

	public void setYearToDateNrc(String yearToDateNrc) {
		this.yearToDateNrc = yearToDateNrc;
	}
}