package com.centuryLink;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ChatResponse {
	@JsonProperty("answer")
	private String answer;

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}
}
